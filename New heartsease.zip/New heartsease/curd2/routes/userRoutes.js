import express from 'express';
import { 
    addUserController,
    showFormController,
    getAllUsersContoller,
    deleteUserController,
    editUserFormController,
    updateUserController
 } from '../controllers/userController.js';

const router = express.Router();

// post route
// localhost:5700/user-form
router.get('/user-form',showFormController);
// localhost:5700/add-user
router.post('/add-user',addUserController);
// get all users
//localhost:5700/all-users
router.get('/all-users',getAllUsersContoller);
//localhost:5700/delete-user
router.get('/delete-user/:id',deleteUserController);
// edit user
// localhost:5700/edit-user
router.get('/edit-user/:id',editUserFormController);
router.post('/update-user/:id',updateUserController);


export default router;