import userModel from "../models/userModel.js";

export const showFormController = async (req, res) => {
  try {
    res.render("index", { title: "home" });
  } catch (error) {
    console.log(error);
  }
};

export const addUserController = async (req, res) => {
  try {
    const user = new userModel({
      name: req.body.username,
      email: req.body.email,
    });
    await user.save();
    // res.redirect('/all-users');
    if(user)
    {
         res.render("index",{msg:"New user added successfully!!"})      
    }

 
    // if (req.accepts("html")) {
    //   res.status(201).send({
    //     success: true,
    //     message: "New user added!!!",
    //     user,
    //   });
    // } 
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "err while adding new user",
      error,
    });
    console.log(error);
  }
};

export const  getAllUsersContoller = async (req,res)=>{
    try {
         const users = await userModel.find({})
        //  console.log(users)
         res.render('users',{users})
    } catch (error) {
      res.status(500).send({
        success:false,
        message:"error while getting all users",
        error
      })   
    }
}

export const deleteUserController = async (req,res)=>{
  try {
         console.log(req.params.id)
        await userModel.findByIdAndDelete(req.params.id);
        res.redirect('/all-users');

  } catch (error) {
    console.log(error)
  }
}

export const editUserFormController = async (req,res)=>{
  try {
       const user =  await userModel.findById(req.params.id);
        // const {id} = req.params
      //  const user =  await userModel.findById(id);
        console.log(user)
        res.render('updateForm',{title:'update',user})

  } catch (error) {
    console.log(error)
  }
}

export const updateUserController = async (req,res)=>{
 try {
        await userModel.findByIdAndUpdate(req.params.id,{
            $set:{
               name:  req.body.username ,
               email: req.body.email
            }
          },{new:true})
          // console.log(user)
          res.redirect('/all-users')

         

 } catch (error) {
  console.log(error)
 }
}