import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

async function main()
{
    await mongoose.connect(process.env.DB_SERVER)
    console.log('Connected to db server...')  
}

export default main;
