import express from 'express';
import dotenv from 'dotenv';
import colors from 'colors';
import expressHbs from 'express-handlebars';
import Handlebars from 'handlebars';
import { allowInsecurePrototypeAccess } from '@handlebars/allow-prototype-access';
import connectDb from './config/config.js';
import userRoute from './routes/userRoutes.js';

const app = express();
dotenv.config();

const PORT = process.env.PORT || 5700
// DATABASE
connectDb();

// express handlebars

app.engine("hbs",
   expressHbs.engine({
     extname:"hbs",
     defaultLayout:"main-layout",
     layoutsDir:"views/layouts",
     handlebars: allowInsecurePrototypeAccess(Handlebars)
   })
)
// template engine hbs
app.set('view engine','hbs');
// app.set("views", "views");

// Route middleware
// localhost:5700/api/v1
app.use(express.urlencoded({extended:false}))

app.use(express.json());
app.use('',userRoute);

app.listen(PORT,
    ()=>console.log(`server is running at localhost:${PORT}`.america))